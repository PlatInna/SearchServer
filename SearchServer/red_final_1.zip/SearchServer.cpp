/* SearchServer.cpp : https://www.coursera.org/ ������ ���������� �� C++: ������� ����, ������ 6. ��������� ������
������� �� ����������������: ��������� �������

*/

#include "search_server.h"
#include "iterator_range.h"

#include <algorithm>
#include <iterator>
#include <sstream>
#include <utility>
#include <iostream>
#include <chrono>

using namespace std::chrono;

vector<string> SplitIntoWords(const string& line) {
    istringstream words_input(line);
    return { istream_iterator<string>(words_input), istream_iterator<string>() };
}

SearchServer::SearchServer(istream& document_input) {
    UpdateDocumentBase(document_input);
}

void SearchServer::UpdateDocumentBase(istream& document_input) {
    InvertedIndex new_index;

    for (string current_document; getline(document_input, current_document); ) {
        new_index.Add(move(current_document));
    }

    index = move(new_index);
}

void SearchServer::AddQueriesStream(
    istream& query_input, ostream& search_results_output
) {
    //vector<size_t> docid_count_v;
    //docid_count_v.resize(50000, 0);
    //docid_count_v.reserve(50000);
    //vector<pair<size_t, size_t>> search_results;
    //search_results.resize(50000, { 0, 0 });
    //vector<pair<size_t, size_t>> search_results(index.GetIndexSize());
    //vector<pair<size_t, size_t>> docid_count_v(50000, { 0, 0 });
    //auto finish = steady_clock::now();
    //auto start = steady_clock::now();
    //auto dur_split = std::chrono::duration_cast<std::chrono::milliseconds>(finish - finish).count();
    //auto dur_lookup = std::chrono::duration_cast<std::chrono::milliseconds>(finish - finish).count();
    //auto dur_lookup_map = std::chrono::duration_cast<std::chrono::milliseconds>(finish - finish).count();
    //auto dur_lookup_vector = std::chrono::duration_cast<std::chrono::milliseconds>(finish - finish).count();
    //auto dur_sort = std::chrono::duration_cast<std::chrono::milliseconds>(finish - finish).count();
    //auto dur_out = std::chrono::duration_cast<std::chrono::milliseconds>(finish - finish).count();

    //vector<pair<size_t, size_t>> search_results(index.GetIndexSize());

    for (string current_query; getline(query_input, current_query); ) {
        
        //start = steady_clock::now();
        const auto words = SplitIntoWords(current_query);
        //finish = steady_clock::now();
        //dur_split += std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

        //start = steady_clock::now();

        //map<size_t, size_t> docid_count;
        //for (const auto& word : words) {
        //    for (const size_t docid : index.Lookup(word)) {
        //        docid_count[docid]++;
        //    }
        //}
        //vector<pair<size_t, size_t>> search_results(
        //    docid_count.begin(), docid_count.end()
        //);

        //finish = steady_clock::now();
        //dur_lookup_map += std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

        //start = steady_clock::now();

        vector<pair<size_t, size_t>> search_results(index.GetDocsSize());

        for (const auto& word : words) {
            //for (const size_t docid : index.Lookup(word)) {
            for (const auto& docid : index.Lookup(word)) {
                //search_results[docid].first = docid;
                //search_results[docid].second ++;
                search_results[docid.first].first = docid.first;
                search_results[docid.first].second += docid.second;
            }
        }

        //vector<pair<size_t, size_t>> search_results_v;
        //for (size_t j = 0; j < docid_count.size(); ++j) {
        //    if (docid_count[j] != 0) {
        //        search_results_v.push_back({ j, docid_count[j] });
        //    }
        //}
        //finish = steady_clock::now();
        //dur_lookup_vector += std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();
        
        //finish = steady_clock::now();
        //dur_lookup += std::chrono::duration_cast<std::chrono::milliseconds>(finish - start_lookup).count();

        //start = steady_clock::now();
        int top_search = 5;
        if (search_results.size() < 5) { top_search = search_results.size(); }
        partial_sort(
            begin(search_results), begin(search_results) + top_search,
            end(search_results),
            [](pair<size_t, size_t> lhs, pair<size_t, size_t> rhs) {
                int64_t lhs_docid = lhs.first;
                auto lhs_hit_count = lhs.second;
                int64_t rhs_docid = rhs.first;
                auto rhs_hit_count = rhs.second;
                return make_pair(lhs_hit_count, -lhs_docid) > make_pair(rhs_hit_count, -rhs_docid);
            }
        );

        //finish = steady_clock::now();
        //dur_sort += std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();

        //start = steady_clock::now();
        

        

        search_results_output << current_query << ':';
        for (auto [docid, hitcount] : Head(search_results, 5)) {
            if (hitcount > 0) {
                search_results_output << " {"
                    << "docid: " << docid << ", "
                    << "hitcount: " << hitcount << '}';
            }
        }
        search_results_output << endl;
        //finish = steady_clock::now();
        //dur_out += std::chrono::duration_cast<std::chrono::milliseconds>(finish - start).count();
    }
    //std::cout << "SplitIntoWords: " << dur_split << endl;
    //std::cout << "index.Lookup_map: " << dur_lookup_map << endl;
    //std::cout << "index.Lookup_vector: " << dur_lookup_vector << endl;
    //std::cout << "index.Lookup: " << dur_lookup << endl;
    //std::cout << "sort: " << dur_sort << endl;
    //std::cout << "out: " << dur_out << endl;

}

void InvertedIndex::Add(const string& document) {
    docs.push_back(document);
    const size_t docid = docs.size() - 1;
    map<string, map<size_t, size_t>> temp;
    for (const auto& word : SplitIntoWords(document)) {
        //index[word].push_back(docid);
        temp[word][docid]++;
    }
    for (auto word : temp) {
        for (auto it : word.second) {
            index[word.first].push_back(it);
        }
    }
}

//list<size_t> InvertedIndex::Lookup(const string& word) const {
vector<pair<size_t, size_t>> InvertedIndex::Lookup(const string & word) const {
    if (auto it = index.find(word); it != index.end()) {
        return it->second;
    }
    else {
        return {};
    }
}
